# scoliosis2 > 2025-04-09 1:05pm
https://universe.roboflow.com/maliqueaa/scoliosis2-hjj02

Provided by a Roboflow user
License: CC BY 4.0

